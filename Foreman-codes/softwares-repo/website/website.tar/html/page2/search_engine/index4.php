<html>
<head>
<title>Title of your search engine</title>
</head>
<body>
<form action='search.php' method='GET'>
<center></br></br></br></br></br></br></br></br>
<h1>Hitachi Search Engine</h1></br>
<input type='text' style="height:30px; width:400px" name='search' placeholder='Enter your text here'></br></br>
<input type='submit'  style="height:30px; width:70px" name='submit' value='Search' ></br></br></br>
</center>
</form>
</body>
</html>
</body>