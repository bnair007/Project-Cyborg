<!DOCTYPE html>
<html>
<body>

<h1>Demonstration for calling Shell Script from a web page</h1>

<a href=”http://192.168.133.177/cgi-bin/first.sh”&gt;
Call my Shell Script</a>

<form action=”cgi-bin/test_script.sh” method=”post”>
<input type=”submit” value=”Call my Shell Script”>
</form>

</body>
</html>
