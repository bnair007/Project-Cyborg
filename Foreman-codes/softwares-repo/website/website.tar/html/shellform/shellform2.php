<?php
$hostname = $_POST['hostname'];
$app = $_POST['app'];
$hosting = $_POST['hosting'];


if(empty($hostname ) || empty($app )) {
echo "<h2>You must fill in all fields</h2>\n" ;
die ("Click Back to start again.");
}
echo "<h2>You Entered the following information:</h2>";
echo "<b>Hostname:</b><br><br>";
echo $hostname;
echo "<br><br><b>Operating System ID:</b><br><br>";
echo $app;
echo "<br><br><b>Hosting ID:</b><br><br>";
echo $hosting;

?>

<?php
#exec ( "/root/foremancli $hostname $shell" );
#exec('sudo /root/foremancli $hostname $shell 2>&1', $output);
#print_r($output);  // to see the response to your command
$output = shell_exec("sudo /root/foremancli '$hostname' '$app'");
echo "<pre>$output</pre>";
?>
